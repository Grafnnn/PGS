/* DEMO_A: minimal presentation fixes on verified rev10. All geometry/data unchanged.
   TROITSK rev06: immutable opened scope, transient selection and filter-safe source context. Geometry unchanged.
   Demand-only geometry, stable global IDs plus scene generation guards.
   No network services. Full active assembly on start; tree expansion loads no geometry. */
'use strict';
(()=>{
const $=id=>document.getElementById(id),K=window.AlbumCore,CAT=window.ALBUM_CATALOG;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n).toLocaleString('ru-RU');
const statusText={active:'Действующая модель',history:'История · не входит в физический экспорт',aux:'Условное / вспомогательное',reference:'Архив R05I',local:'Локальная форма · не установлена',proposal:'Предложение · не применено',test:'Тест · не установлен',template:'Локальный образец'};
const loadLog=[],waiting=new Map(),dataCache=new Map(),blockCache=new Map(),blockInflight=new Map();
let rows=[],logical={},keyMap=new Map(),children=new Map(),replacements=new Map(),modules=new Map(),blockMap=new Map(),INDEX=null;
let S={module:null,page:null,scene:[],visible:[],hidden:[],selection:null,cardIds:[],filters:{level:'',state:'',zone:'',axis:''},tab:'pages',elementPage:0,pageListPage:0,relationsPage:0,camera:{yaw:-.95,pitch:.68,target:[0,0,0],size:65,scale:8,pan:[0,0]},clip:null,opacity:1,explode:1,full:false};
let navigationSerial=0,drawingSession=0,visibilityRevision=0;
function beginNavigation(opts={}){if(opts.navToken!=null)return opts.navToken;drawingSession++;drawingTicket++;selectTicket++;return ++navigationSerial;}
function navigationCurrent(token){return token===navigationSerial;}
let generation=0,selectTicket=0,worker=null,workerReady=false,workerBusy=false,pendingRender=false,seq=0,pick=null,pickGeneration=-1,lastFrame=null,activeBlocks=[],fullRecords=new Map(),pageData=new Map(),sourcesData=null;
let beforeDrawing=null,beforeBuilding=null,searchPage=0,searchMatches=[],drawingTicket=0;
let stored=[];try{stored=JSON.parse(localStorage.getItem('B24_ALBUM_R10_UI_VIEWS')||'[]')}catch(_){}
const canvas=$('canvas'),ctx=canvas.getContext('2d',{alpha:false});
function log(type,o={}){loadLog.push({t:performance.now(),type,...o});if(loadLog.length>1200)loadLog.shift();}
function toast(s){$('toast').textContent=s;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,6500);}
function error(e){console.error(e);window.ALBUM_LAST_ERROR=String(e.stack||e);$('sceneLoading').hidden=true;toast('Не удалось открыть вид. Проверьте, что весь альбом распакован в одну папку.');}
function dialog(title,html){$('dialogTitle').textContent=title;$('dialogBody').innerHTML=html;if(!$('dialog').open)$('dialog').showModal();}
$('dialogClose').onclick=()=>$('dialog').close();
function rawBase64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
async function decode(s){if(!window.DecompressionStream)throw new Error('Нужен браузер с DecompressionStream: современный Chrome/Edge.');const bytes=rawBase64(s);const raw=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();return JSON.parse(new TextDecoder().decode(raw));}
window.ALBUM_ACCEPT=async(key,packed)=>{const w=waiting.get(key);if(!w)return;try{const d=await decode(packed);log('decoded',{key});w.resolve(d);}catch(e){w.reject(e);}};
function script(path){return new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=path;s.onload=()=>{s.remove();resolve()};s.onerror=()=>{s.remove();reject(new Error('Не найден файл '+path+'. Распакуйте пакет целиком.'))};document.head.append(s);});}
function loadData(key,path,keep=true){if(keep&&dataCache.has(key))return Promise.resolve(dataCache.get(key));if(waiting.has(key))return waiting.get(key).promise;let w={};w.promise=new Promise((resolve,reject)=>{w.resolve=resolve;w.reject=reject});waiting.set(key,w);log('request',{key,path});script(path).catch(w.reject);return w.promise.then(d=>{waiting.delete(key);if(keep)dataCache.set(key,d);return d;},e=>{waiting.delete(key);throw e;});}
function prepareIndex(){if(INDEX)return INDEX;INDEX=loadData('index','data/index.js').then(d=>{rows=d.rows||d.values.map(v=>Object.fromEntries(d.columns.map((k,j)=>[k,v[j]])));logical=d.logical;keyMap=new Map(rows.map((e,i)=>[e.key,i]));for(let i=0;i<rows.length;i++){const e=rows[i];if(e.parent){let pk=e.parent_key||(e.ns==='world'?e.parent:e.ns+'::'+e.parent);if(!children.has(pk))children.set(pk,[]);children.get(pk).push(i);}if(e.supersedes){let k=e.ns==='world'?e.supersedes:e.ns+'::'+e.supersedes;if(!replacements.has(k))replacements.set(k,[]);replacements.get(k).push(i);}}window.ALBUM_INDEX_READY=true;log('index_ready',{keys:rows.length});return d;});return INDEX;}
async function pages(mod){if(pageData.has(mod))return pageData.get(mod);const p=await loadData('pages/'+mod,'pages/'+mod+'.js');pageData.set(mod,p);return p;}
async function getBlock(id){if(blockCache.has(id)){const b=blockCache.get(id);b.lastUsed=performance.now();return b;}if(blockInflight.has(id))return blockInflight.get(id);const task=(async()=>{const b=await loadData('block/'+id,'blocks/'+id+'.js',false);b.binary=rawBase64(b.geometry_b64).buffer;delete b.geometry_b64;b.lastUsed=performance.now();blockCache.set(id,b);return b;})();blockInflight.set(id,task);try{return await task;}finally{blockInflight.delete(id);}}
function trimCache(needed){const keep=new Set(needed),old=[...blockCache.values()].filter(b=>!keep.has(b.id)).sort((a,b)=>b.lastUsed-a.lastUsed);let kept=false;for(const b of old){if(!kept&&b.binary.byteLength<=32*1024*1024){kept=true;continue;}blockCache.delete(b.id);log('evicted',{id:b.id});}}
function bnds(ids){if(!ids.length)return [[0,0,0],[1,1,1]];const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];for(const i of ids){const b=rows[i]?.bounds;if(!b)continue;for(let a=0;a<3;a++){lo[a]=Math.min(lo[a],b[0][a]);hi[a]=Math.max(hi[a],b[1][a]);}}return[lo,hi];}
function fit(ids){const b=bnds(ids),r=$('stage').getBoundingClientRect();S.camera.target=b[0].map((v,a)=>(v+b[1][a])/2);S.camera.size=Math.max(.25,Math.hypot(...b[0].map((v,a)=>b[1][a]-v)));S.camera.scale=Math.max(.05,Math.min(r.width,r.height)*.78/S.camera.size);S.camera.pan=[0,0];}
function visibleIds(){const hidden=new Set(S.hidden);return K.filtered(S.scene,rows,S.filters).filter(i=>!hidden.has(i));}
function updateVisible(){return reconcileVisibility('visibility');}
function offsets(){const p=S.page,rule=p?.explode;if(!rule)return{};let out={};for(const i of S.scene){const e=fullRecords.get(i)||rows[i];let v=0;if(rule==='roof'){const n=['level','vapor','clay','residual','xps','screed','membrane_lower','membrane_upper'].indexOf(e.category);if(n>=0)v=(n+1)*.55;}else if(rule==='sample'){const n=['detail_S','detail_L','detail_V','detail_K','detail_X','detail_C','detail_M'].indexOf(e.category);if(n>=0)v=n*.18;}else if(rule==='floor'){v=({'R08_AR_FLOOR_SCREED':.30,'R08_AR_FLOOR_LEVEL':.55,'R08_AR_FLOOR_GLUE':.80,'R08_AR_FLOOR_TILE':1.05})[e.id]||0;}else if(rule==='old'&&e.category.startsWith('old')){v=(+e.category.slice(-1)||0)*.24;}else if(typeof rule==='object'){if(rule[e.category]!==undefined)v=+rule[e.category]||0;else if(rule[e.id]!==undefined)v=+rule[e.id]||0;else if(rule.categories?.[e.category]!==undefined)v=+rule.categories[e.category]||0;}out[i]=v*S.explode;}return out;}
function render(){pick=null;pickGeneration=-1;if(!workerReady||!worker)return;if(workerBusy){pendingRender=true;return;}const r=$('stage').getBoundingClientRect();if(r.width<20||r.height<20)return;workerBusy=true;const sel=S.selection!=null?keyMap.get(S.selection):-1;worker.postMessage({type:'render',seq:++seq,width:Math.round(r.width),height:Math.round(r.height),camera:S.camera,visible:S.visible,selected:sel??-1,selectedIndices:S.selection?[]:(currentTreeId()&&currentTreeId()!=='building'?S.cardIds:[]),opacity:S.opacity,clip:S.clip,offsets:offsets()});}
async function install(ids,token,navToken=navigationSerial){if(!navigationCurrent(navToken)||token!==generation)return false;pick=null;pickGeneration=-1;workerReady=false;if(worker){worker.terminate();worker=null;}workerBusy=false;pendingRender=false;const need=K.unique(ids.map(i=>rows[i].block));$('loadDetail').textContent='';const bs=new Array(need.length);let cursor=0;await Promise.all(Array.from({length:Math.min(8,need.length)},async()=>{while(cursor<need.length&&token===generation&&navigationCurrent(navToken)){const at=cursor++;bs[at]=await getBlock(need[at]);}}));if(token!==generation||!navigationCurrent(navToken)){trimCache(activeBlocks);return false;}
activeBlocks=need;trimCache(need);fullRecords=new Map();let nv=0,nf=0;for(const b of bs){nv+=b.vertices;nf+=b.faces;for(const e of b.records)fullRecords.set(e.global_index,e);}
const buffer=new ArrayBuffer(nv*12+nf*15),vv=new Float32Array(buffer,0,nv*3),ff=new Uint32Array(buffer,nv*12,nf*3),nn=new Int8Array(buffer,nv*12+nf*12,nf*3),info=new Array(rows.length),meta=new Array(rows.length);let vo=0,fo=0;
for(const b of bs){vv.set(new Float32Array(b.binary,0,b.vertices*3),vo*3);const f=new Uint32Array(b.binary,b.vertices*12,b.faces*3);for(let j=0;j<f.length;j++)ff[fo*3+j]=f[j]+vo;nn.set(new Int8Array(b.binary,b.vertices*12+b.faces*12,b.faces*3),fo*3);for(const [i,a,vc,c,fc]of b.info){info[i]=[vo+a,vc,fo+c,fc];const e=rows[i];meta[i]={bounds:e.bounds,rgb:[1,3,5].map(k=>parseInt((e.color||'#999999').slice(k,k+2),16))};}vo+=b.vertices;fo+=b.faces;}
const url=URL.createObjectURL(new Blob([window.ALBUM_WORKER_SOURCE],{type:'application/javascript'}));const w=new Worker(url);URL.revokeObjectURL(url);worker=w;
w.onmessage=ev=>{if(token!==generation||worker!==w)return;const m=ev.data;if(m.type==='ready'){workerReady=true;render();}else if(m.type==='frame'){workerBusy=false;canvas.width=m.width;canvas.height=m.height;ctx.putImageData(new ImageData(new Uint8ClampedArray(m.pixels),m.width,m.height),0,0);lastFrame={generation:token,seq:m.seq,ms:m.ms,width:m.width,height:m.height,triangles:m.triangles_tested};if(!pendingRender){pick=new Int32Array(m.owner);pickGeneration=token;}$('sceneLoading').hidden=true;$('renderStats').textContent=fmt(S.visible.length)+' видимых · '+fmt(m.triangles_tested)+' треуг. · '+Math.round(m.ms)+' мс';$('resident').textContent=activeBlocks.length+' блоков / '+fmt(nv*12+nf*15)+' байт Worker';window.ALBUM_RENDERED=true;drawOverlay();if(pendingRender){pendingRender=false;render();}}else if(m.type==='error'){error(new Error(m.error));}};
w.onerror=e=>error(new Error(e.message));w.postMessage({type:'init',buffer,vertices:nv,faces:nf,info,meta},[buffer]);log('scene_installed',{generation:token,blocks:need,ids:ids.length,vertices:nv,faces:nf,bytes:nv*12+nf*15});return true;}
function resetFilters(){S.filters={level:'',state:'',zone:'',axis:''};S.hidden=[];S.clip=null;S.opacity=1;S.explode=1;syncControls();}
function syncControls(){for(const k of ['level','state','zone','axis'])$(k).value=S.filters[k]||'';$('opacity').value=S.opacity*100;$('explode').value=S.explode;if(S.clip){let a=S.clip.findIndex(b=>b[1]<99999);$('clipAxis').value=String(a);$('clipValue').value=S.clip[a][1];}else $('clipAxis').value='';}
function legacy_chapterOptions(){const ps=pageData.get(S.module)||[],ids=K.unique(ps.flatMap(p=>p.indices));for(const [field,label]of [['level','Все подтверждённые уровни'],['zone','Все подтверждённые зоны'],['axis','Все подтверждённые оси']]){const values=K.unique(ids.map(i=>rows[i][field]).filter(Boolean)).sort((a,b)=>a.localeCompare(b,'ru',{numeric:true}));$(field).innerHTML='<option value="">'+label+'</option>'+values.map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('');}}
function legacy_updatePageBar(){const mod=modules.get(S.module),ps=pageData.get(S.module)||[];const n=ps.findIndex(p=>p.key===S.page?.key);$('sectionTitle').textContent=mod.name;$('sectionCounts').textContent=mod.pages+' страниц · '+fmt(mod.physical)+' физических у владельца';$('breadcrumb').textContent='Троицк Б24 → '+mod.name+' → '+(S.page?.group||'');$('pageTitle').textContent=S.page?.name||'';$('pageNumber').textContent=(n+1)+' / '+ps.length;$('prev').disabled=n<=0;$('next').disabled=n<0||n===ps.length-1;$('sceneLabel').textContent=S.module==='master'&&!S.full?'Обзорная оболочка; детали доступны отдельными блоками':statusText[rows[S.scene[0]]?.bucket]||'Модель выбранной страницы';$('pageHint').textContent=S.page?.hint||'';$('explodeLabel').hidden=!S.page?.explode;}
async function legacy_openPage(mod,id,options={}){const token=++generation;selectTicket++;$('homePanel').hidden=true;$('album').hidden=false;$('searchPanel').hidden=true;$('drawingPanel').hidden=true;$('sceneLoading').hidden=false;
try{await prepareIndex();const ps=await pages(mod);if(token!==generation)return;const p=ps.find(p=>p.id===id); if(!p)throw new Error('Страница не найдена: '+mod+'/'+id);S.module=mod;S.page=p;S.full=!!options.full;S.selection=null;S.cardIds=[];S.elementPage=0;S.pageListPage=Math.floor(ps.indexOf(p)/50);S.relationsPage=0;S.tab='pages';resetFilters();chapterOptions();S.scene=(mod==='master'&&['overview','plan','structure'].includes(p.id)&&!S.full)?rows.map((e,i)=>e.bucket==='active'&&e.physical?i:-1).filter(i=>i>=0):p.indices.slice();if(options.extra!=null&&!S.scene.includes(options.extra))S.scene.push(options.extra);S.visible=S.scene.slice();Object.assign(S.camera,K.cameraEye(p.eye));fit(S.scene);if(p.clip&&p.range){S.clip=structuredClone(p.range);syncControls();}if(!await install(S.scene,token))return;updatePageBar();drawPages();setTab('pages');pageCard();if(!options.noHash)history.replaceState(null,'','#page/'+encodeURIComponent(mod)+'/'+encodeURIComponent(p.id));if(options.select!=null)select(options.select,true);log('page_ready',{key:p.key,generation:token});}catch(e){if(token===generation)error(e);}}
function legacy_home(){generation++;selectTicket++;if(worker)worker.terminate();worker=null;workerReady=false;pick=null;pickGeneration=-1;activeBlocks=[];fullRecords.clear();trimCache([]);S.scene=[];S.visible=[];S.selection=null;S.page=null;S.module=null;$('homePanel').hidden=false;$('album').hidden=true;$('searchPanel').hidden=true;$('drawingPanel').hidden=true;history.replaceState(null,'','#contents');log('home',{geometry:0});}
function pager(container,ids,page,size,cb){const s=K.slicePage(ids,page,size);container.innerHTML='';const prev=document.createElement('button');prev.textContent='← Назад';prev.disabled=s.page===0;prev.onclick=()=>cb(s.page-1,'prev');const label=document.createElement('span');label.textContent=ids.length?(s.start+1)+'–'+s.end+' / '+fmt(ids.length):'0';const next=document.createElement('button');next.textContent='Далее →';next.disabled=s.page===s.pages-1;next.onclick=()=>cb(s.page+1,'next');container.append(prev,label,next);return s;}
function legacy_drawPages(){const list=$('pageList'),ps=pageData.get(S.module)||[];const prevScroll=list.scrollTop;list.innerHTML='';const s=K.slicePage(ps,S.pageListPage,50);S.pageListPage=s.page;let label='';for(const p of s.ids){const g=p.kind==='original'?'Исходные виды · '+(p.group||'Раздел'):'Узлы · '+p.group;if(g!==label){const el=document.createElement('span');el.className='list-label';el.textContent=g;list.append(el);label=g;}const b=document.createElement('button');b.className='pageitem'+(p.key===S.page?.key?' selected':'');b.dataset.page=p.key;b.innerHTML='<b>'+p.number+'. '+esc(p.name)+'</b><small>'+fmt(p.indices.length)+' записей · '+p.blocks.length+' блоков</small>';b.onclick=()=>openPage(S.module,p.id);list.append(b);}const nav=document.createElement('div');nav.className='pager';list.append(nav);pager(nav,ps,S.pageListPage,50,(page,focus)=>{S.pageListPage=page;drawPages();list.scrollTop=0;const buttons=list.querySelector('.pager').querySelectorAll('button');buttons[focus==='next'?1:0].focus();});list.scrollTop=prevScroll;}
function legacy_setTab(tab){S.tab=tab;$('pageList').hidden=tab!=='pages';$('elementPanel').hidden=tab!=='elements';$('pagesTab').classList.toggle('on',tab==='pages');$('elementsTab').classList.toggle('on',tab==='elements');if(tab==='elements')drawElements();}
function legacy_drawElements(){if(!rows.length)return;const ids=K.filtered(S.scene,rows,S.filters),s=K.slicePage(ids,S.elementPage,60);S.elementPage=s.page;$('elementPath').textContent=(modules.get(S.module)?.name||'')+' → '+(S.page?.name||'');const list=$('elementList');list.innerHTML='';for(const i of s.ids){const e=rows[i],b=document.createElement('button');b.className='elementitem'+(e.key===S.selection?' selected':'');b.dataset.key=e.key;b.innerHTML='<b>'+esc(e.name)+'</b><small>'+esc(e.key)+'<br>'+esc(e.level)+' · '+esc(e.partial?'Частичное тело':statusText[e.bucket])+(S.hidden.includes(i)?' · скрыт':'')+'</small>';b.onclick=()=>select(i,true);list.append(b);}pager($('elementPagination'),ids,S.elementPage,60,(page,focus)=>{S.elementPage=page;drawElements();$('elementPanel').scrollTop=0;const bs=$('elementPagination').querySelectorAll('button');bs[focus==='next'?1:0].focus();});}
const field=(name,value)=>'<div class="field"><label>'+esc(name)+'</label><div>'+esc(typeof value==='object'?JSON.stringify(value):value??'—')+'</div></div>';
function legacy_pageCard(){S.selection=null;S.cardIds=K.filtered(S.scene,rows,S.filters);$('properties').innerHTML='<h2>'+esc(S.page?.name||'Страница')+'</h2><span class="status">Страница / группа</span>'+field('Состав',S.cardIds.length+' записей')+field('Физические тела',S.cardIds.filter(i=>rows[i].physical).length)+'<p class="note">Выберите элемент в модели или списке. «Изолировать» и «Скрыть» действуют на эту страницу.</p>';}
function legacy_relationList(container,ids,title){if(!ids.length)return;const h=document.createElement('h3');h.textContent=title+' · '+ids.length;container.append(h);const area=document.createElement('div'),nav=document.createElement('div');nav.className='pager';container.append(area,nav);let page=0;function paint(){area.innerHTML='';const s=K.slicePage(ids,page,50);for(const i of s.ids){const b=document.createElement('button');b.className='relationitem';b.textContent=rows[i].key+' · '+rows[i].name;b.onclick=()=>openRecord(rows[i].key);area.append(b);}pager(nav,ids,page,50,(v,f)=>{page=v;paint();nav.querySelectorAll('button')[f==='next'?1:0].focus();});}paint();}
function legacy_elementCard(i){const e=fullRecords.get(i)||rows[i],p=e.props||{};const path=[modules.get(e.module)?.name,e.level,e.group,e.name].join(' → ');let html='<h2>'+esc(e.name)+'</h2><span class="status '+esc(e.partial?'partial':e.bucket)+'">'+esc(e.partial?'Частичная геометрия':statusText[e.bucket])+'</span>'+field('Путь',path)+field('ID / пространство',e.key)+field('Уровень',e.level)+field('Основание уровня',e.level_basis||'Сохранено из FULL_NAV rev02; откройте полные свойства')+field('Марка',p.mark||e.group)+field('Материал',p.material||p.bar_class||p.source_profile)+field('Количество / единицы',p.quantity??p.model_quantity??p.bar_count??'не задано')+field('Ед. изм.',p.unit)+field('Габарит меша, м',e.bounds[0].map((v,a)=>(e.bounds[1][a]-v).toFixed(6)).join(' × '));
for(const k of ['length_m','source_length_mm','source_pdf_page','source_sheet','source','confidence','note'])if(p[k]!=null)html+=field(k,p[k]);html+='<div class="card-actions"><button id="propFocus">Приблизить</button><button id="propIsolate">Изолировать</button><button id="propHide">Скрыть</button></div>';
if(e.parent)html+='<button class="source-link" id="parentButton">Родитель: '+esc(e.parent)+'</button>';
html+='<button class="source-link" id="propDrawing">Чертёж — источник элемента</button><details><summary>Все исходные свойства</summary><pre>'+esc(JSON.stringify(p,null,2))+'</pre></details><div id="relations"></div>';$('properties').innerHTML=html;
$('propFocus').onclick=()=>{fit([i]);render()};$('propIsolate').onclick=()=>isolate([i]);$('propHide').onclick=()=>hide([i]);$('propDrawing').onclick=showDrawing;
if($('parentButton'))$('parentButton').onclick=()=>openRecord(e.parent_key||(e.ns==='world'?e.parent:e.ns+'::'+e.parent));relationList($('relations'),children.get(e.key)||[],'Дочерние записи');relationList($('relations'),replacements.get(e.key)||[],'История замены');if(e.supersedes){const b=document.createElement('button');b.className='relationitem';b.textContent='Заменённая запись: '+e.supersedes;b.onclick=()=>openRecord(e.ns==='world'?e.supersedes:e.ns+'::'+e.supersedes);$('relations').append(b);}}
function legacy_select(i,focus=true){if(!rows[i])return;if(!S.scene.includes(i)){openRecord(rows[i].key);return;}S.selection=rows[i].key;S.cardIds=[i];S.hidden=S.hidden.filter(v=>v!==i);if(!K.filtered([i],rows,S.filters).length){S.filters={level:'',state:'',zone:'',axis:''};syncControls();toast('Фильтр сброшен для выбранного элемента.');}S.visible=visibleIds();S.elementPage=Math.floor(K.filtered(S.scene,rows,S.filters).indexOf(i)/60);setTab('elements');elementCard(i);if(focus)fit([i]);render();const b=$('elementList').querySelector('[data-key="'+CSS.escape(rows[i].key)+'"]');b?.scrollIntoView({block:'nearest'});}
async function legacy_openRecord(key){const ticket=++selectTicket;await prepareIndex();if(ticket!==selectTicket)return;const i=keyMap.get(key);if(i!=null){if(S.scene.includes(i)){select(i,true);$('searchPanel').hidden=true;return;}const e=rows[i];await openPage(e.module,'node_D01_'+e.block,{select:i});return;}const node=logical[key];if(node){const ids=children.get(key)||node.children;if(!ids.length){toast('Логический узел без дочерней геометрии.');return;}await openPage(rows[ids[0]].module,'node_D01_'+rows[ids[0]].block);S.selection=null;S.cardIds=ids;$('properties').innerHTML='<h2>'+esc(node.name)+'</h2>'+field('Состояние','Логический родитель без собственного меша')+'<div id="logicalRelations"></div>';relationList($('logicalRelations'),ids,'Дети');return;}toast('Запись '+key+' отсутствует; фиктивное тело не создано.');}
function legacy_targets(){return S.cardIds.length?S.cardIds:S.selection!=null?[keyMap.get(S.selection)]:S.scene;}
async function isolate(ids,opts={}){
 const navToken=beginNavigation(opts);if(!ids.length||!navigationCurrent(navToken))return false;
 const token=++generation;S.scene=ids.slice();S.hidden=[];S.visible=ids.slice();S.filters={level:'',state:'',zone:'',axis:''};syncControls();$('sceneLoading').hidden=false;fit(ids);
 if(!await install(ids,token,navToken)||!navigationCurrent(navToken))return false;reconcileVisibility('isolate',{invalidate:false});return true;
}
function hide(ids){S.hidden=K.unique(S.hidden.concat(ids));reconcileVisibility('hide');drawLayers();}
function legacy_snapshot(){return{...structuredClone(S),pageKey:S.page?.key,listScroll:$('pageList').scrollTop,elementScroll:$('elementPanel').scrollTop,propertyScroll:$('properties').scrollTop};}
async function legacy_restore(s){if(!s)return;const parts=s.pageKey?.split('::');if(!parts){home();return;}const token=++generation;await prepareIndex();await pages(parts[0]);$('homePanel').hidden=true;$('album').hidden=false;$('drawingPanel').hidden=true;S=structuredClone(s);S.page=(pageData.get(parts[0])||[]).find(p=>p.key===s.pageKey);if(!S.page)return home();chapterOptions();syncControls();$('sceneLoading').hidden=false;await install(S.scene,token);S.visible=visibleIds();updatePageBar();drawPages();setTab(S.tab);if(S.selection&&keyMap.has(S.selection))elementCard(keyMap.get(S.selection));else pageCard();$('pageList').scrollTop=s.listScroll||0;$('elementPanel').scrollTop=s.elementScroll||0;$('properties').scrollTop=s.propertyScroll||0;history.replaceState(null,'','#page/'+encodeURIComponent(parts[0])+'/'+encodeURIComponent(parts[1]));render();}
async function legacy_runSearch(){const q=$('search').value;await prepareIndex();if(q!==$('search').value)return;searchMatches=K.searchRows(rows,q);searchPage=0;drawSearch();}
function legacy_drawSearch(){const q=$('search').value.trim();if(!q){$('searchPanel').hidden=true;return;}$('searchPanel').hidden=false;$('searchCount').textContent=fmt(searchMatches.length)+' совпадений по всему альбому';const list=$('searchResults');list.innerHTML='';const s=K.slicePage(searchMatches,searchPage,40);for(const i of s.ids){const e=rows[i],b=document.createElement('button');b.className='resultitem';b.dataset.key=e.key;b.innerHTML='<b>'+esc(e.name)+'</b><small>'+esc(e.key)+'<br>'+esc(modules.get(e.module)?.name)+' → '+esc(e.level)+' → '+esc(e.group)+'<br>'+esc(e.partial?'Частичное тело':statusText[e.bucket])+'</small>';b.onclick=()=>openRecord(e.key);list.append(b);}if(!s.ids.length)list.innerHTML='<p class="note">Совпадений нет. Поиск не меняет состав модели.</p>';pager($('searchPagination'),searchMatches,searchPage,40,(p,f)=>{searchPage=p;drawSearch();$('searchResults').scrollTop=0;$('searchPagination').querySelectorAll('button')[f==='next'?1:0].focus();});}
let searchTimer;$('search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(runSearch,90)};$('searchClear').onclick=()=>{$('search').value='';$('searchPanel').hidden=true};$('searchClose').onclick=()=>$('searchPanel').hidden=true;
async function ensurePack(file){return window.ALBUM_SOURCE_FILES?.[file]?{ok:true}:{ok:false,message:'Путь чертежа не зарегистрирован: '+file};}
async function sources(){if(!sourcesData)sourcesData=await loadData('sources','data/sources.js');return sourcesData;}
async function legacy_openSource(key,mode='Прямая связь'){const ticket=++drawingTicket,{sources:ss}=await sources();const s=ss[key];if(!s){$('drawingResource').innerHTML='<p class="note warning">Точная привязка источника отсутствует: '+esc(key)+'</p>';return;}$('drawingTitle').textContent=s.title;$('drawingInfo').textContent=mode+' · Лист: '+(s.printed_sheet??'не установлен')+' · Физическая страница PDF: '+(s.pdf_page??'не установлена')+' · '+key;$('drawingResource').innerHTML='<p class="loadingtext">Открываем чертёж…</p>';const pk=await ensurePack(s.file);if(ticket!==drawingTicket)return;const body=$('drawingResource');body.innerHTML='';if(pk.ok){const img=document.createElement('img');img.alt=s.title;img.src=s.file;img.onerror=()=>{body.insertAdjacentHTML('afterbegin','<p class="note warning">Файл источника не открылся: '+esc(s.file)+'. Проверьте распаковку пакета.</p>');};body.append(img);}else{const msg=document.createElement('p');msg.className='note warning';msg.textContent=pk.message;body.append(msg);}
if(s.pdf&&s.pdf_page){const b=document.createElement('button');b.textContent='Полный PDF · страница '+s.pdf_page;b.className='source-link';b.onclick=async()=>{const pdfpk=await ensurePack(s.pdf);if(!pdfpk.ok){toast(pdfpk.message);return;}const url=s.pdf+'#page='+s.pdf_page;const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';a.textContent='Открыть этот лист в новой вкладке';const iframe=document.createElement('iframe');iframe.title=s.title;iframe.src=url;body.replaceChildren(a,iframe);};body.prepend(b);}else body.insertAdjacentHTML('beforeend','<p class="note">Связь с физической страницей полного PDF не подтверждена. Показано собственное изображение, номер страницы не подставлен.</p>');}
async function legacy_showDrawing(){beforeDrawing=snapshot();$('drawingPanel').hidden=false;$('drawingContext').textContent=[modules.get(S.module)?.name,S.page?.name,S.selection].filter(Boolean).join(' → ');$('drawingList').innerHTML='<p>Загрузка реестра…</p>';const {sources:ss,extras}=await sources();const i=keyMap.get(S.selection),res=K.sourcePriority(i,rows,ss,keyMap,S.page);let links=res.links.slice();if(S.selection&&extras[S.selection])links.push(...extras[S.selection]);const nav=(rows[i]?.sources||[]).filter(s=>s.method==='navigation_evidence'&&ss[s.key]);links.push(...nav);links=links.filter((s,n,a)=>a.findIndex(x=>x.key===s.key)===n);const list=$('drawingList');list.innerHTML='<p class="sourcehint">'+esc(res.mode)+'</p>';for(const l of links){const b=document.createElement('button');b.className='source-link';b.dataset.source=l.key;b.innerHTML=esc(ss[l.key]?.title||l.key)+'<small> · '+esc(l.method||res.mode)+'</small>';b.onclick=()=>openSource(l.key,l.method==='navigation_evidence'?'Основание уровня, не деталь':res.mode);list.append(b);}if(links.length)openSource(links[0].key,res.mode);else{$('drawingTitle').textContent='Точная привязка не задана';$('drawingInfo').textContent=S.selection||S.page?.key||'';$('drawingResource').innerHTML='<p class="note warning">Для текущего выбора нет подтверждённого чертежа. Общий лист не подставлен. Документы и открытые вопросы доступны из оглавления.</p>';}}
$('drawing').onclick=showDrawing;$('cardDrawing').onclick=showDrawing;$('backModel').onclick=()=>{drawingTicket++;$('drawingPanel').hidden=true;restore(beforeDrawing).catch(error)};
$('documents').onclick=async()=>{const docs=await loadData('documents','data/documents.js');dialog('Документы',docs.map((o,i)=>'<button class="source-link" data-doc="'+i+'">'+esc(o.name)+'<small> · '+esc(o.kind||'')+'</small></button>').join(''));for(const b of $('dialogBody').querySelectorAll('[data-doc]'))b.onclick=async()=>{const o=docs[+b.dataset.doc],p=await ensurePack(o.file);if(!p.ok)return toast(p.message);window.open(o.file,'_blank','noopener');};};
$('questions').onclick=async()=>{const issues=await loadData('issues','data/issues.js');dialog('Незакрытые вопросы',issues.map(o=>'<h3>'+esc(o.id+' · '+o.title)+'</h3><p>'+esc(o.text)+'</p><small>'+esc(o.source)+'</small>').join(''));};
$('saved').onclick=()=>{dialog('Мои сохранённые виды',stored.length?stored.map((s,i)=>'<button class="source-link" data-saved="'+i+'">'+esc(s.label)+'</button>').join(''):'<p>Сохранённых видов ещё нет.</p>');for(const b of $('dialogBody').querySelectorAll('[data-saved]'))b.onclick=()=>{$('dialog').close();restore(stored[+b.dataset.saved].state).catch(error)};};
$('saveView').onclick=()=>{const label=prompt('Название вида',S.page?.name||'Мой вид');if(label===null)return;stored.push({label,state:snapshot()});try{localStorage.setItem('B24_ALBUM_D01_VIEWS',JSON.stringify(stored));}catch(_){toast('Вид сохранён только в текущем открытии.');}toast('Сохранены страница, выбор, камера, фильтры, видимость, сечение и разнесение.');};
$('inBuilding').onclick=()=>{if(pageMeta(S.page)?.isType&&!beforeBuilding)return toast('Тип без размещения. Мировая установка не задана.');if(beforeBuilding){const old=beforeBuilding;beforeBuilding=null;$('inBuilding').textContent='В здании';return restore(old).catch(error);}const i=keyMap.get(S.selection);if(i!=null&&(rows[i].ns!=='world'||rows[i].bucket!=='active'))return toast('У этого объекта нет принятой мировой установки.');beforeBuilding=snapshot();$('inBuilding').textContent='К узлу';openPage('master','overview',{extra:i,select:i});};
$('home').onclick=home;$('contents').onclick=home;$('buildingOverview').onclick=()=>openPage('master','overview');$('pagesTab').onclick=()=>setTab('pages');$('elementsTab').onclick=()=>setTab('elements');
$('prev').onclick=()=>{const ps=pageData.get(S.module),n=ps.findIndex(p=>p.key===S.page.key);if(n>0)openPage(S.module,ps[n-1].id)};$('next').onclick=()=>{const ps=pageData.get(S.module),n=ps.findIndex(p=>p.key===S.page.key);if(n<ps.length-1)openPage(S.module,ps[n+1].id)};
$('showPage').onclick=()=>{resetFilters();S.scene=S.full?S.page.indices.slice():(S.module==='master'&&['overview','plan','structure'].includes(S.page.id)?rows.map((e,i)=>e.bucket==='active'&&e.physical?i:-1).filter(i=>i>=0):S.page.indices.slice());const token=++generation;S.visible=S.scene.slice();fit(S.scene);install(S.scene,token).then(()=>{pageCard();drawElements()}).catch(error)};
$('loadDetails').onclick=()=>openPage(S.module,S.page.id,{full:true});$('showModulePages').onclick=()=>{S.pageListPage=0;setTab('pages');drawPages();$('pageList').scrollTop=0;};
$('isolate').onclick=()=>isolate(targets()).catch(error);$('hide').onclick=()=>hide(targets());$('restore').onclick=()=>{S.hidden=[];updateVisible();};$('fit').onclick=()=>{fit(targets());render()};
for(const b of document.querySelectorAll('[data-cam]'))b.onclick=()=>{const cfg={top:[-.5,Math.PI/2-.0003],front:[-Math.PI/2,0],side:[0,0],iso:[-.95,.68]}[b.dataset.cam];[S.camera.yaw,S.camera.pitch]=cfg;fit(S.visible);render();};
for(const k of ['level','state','zone','axis'])$(k).onchange=()=>{S.filters[k]=$(k).value;S.elementPage=0;reconcileVisibility('filter:'+k);fit(S.visible);setTab('elements');render();};
$('opacity').oninput=()=>{S.opacity=+$('opacity').value/100;render()};function setClip(){const a=$('clipAxis').value;if(a===''){S.clip=null;render();return;}S.clip=[[-100000,100000],[-100000,100000],[-100000,100000]];S.clip[+a][1]=+$('clipValue').value;render();}$('clipAxis').onchange=()=>{const a=$('clipAxis').value;if(a!==''){const b=bnds(S.visible);$('clipValue').value=((b[0][+a]+b[1][+a])/2).toFixed(3);}setClip();};$('clipValue').onchange=setClip;$('explode').oninput=()=>{S.explode=+$('explode').value;render()};$('png').onclick=()=>{const a=document.createElement('a');a.href=canvas.toDataURL('image/png');a.download='Troitsk_'+(S.page?.id||'view')+'.png';a.click();};
let drag=null;canvas.addEventListener('pointerdown',ev=>{drag={x:ev.clientX,y:ev.clientY,px:ev.clientX,py:ev.clientY,moved:0,shift:ev.shiftKey||ev.button===2};canvas.setPointerCapture(ev.pointerId)});canvas.addEventListener('pointermove',ev=>{if(!drag)return;const dx=ev.clientX-drag.px,dy=ev.clientY-drag.py;drag.moved+=Math.abs(dx)+Math.abs(dy);drag.px=ev.clientX;drag.py=ev.clientY;if(drag.moved<4)return;if(drag.shift){S.camera.pan[0]+=dx;S.camera.pan[1]+=dy;}else{S.camera.yaw-=dx*.008;S.camera.pitch=Math.max(-1.56,Math.min(1.5705,S.camera.pitch+dy*.008));}render();});canvas.addEventListener('pointerup',ev=>{if(!drag)return;const moved=drag.moved;drag=null;if(moved>4||!pick||pickGeneration!==generation)return;const r=canvas.getBoundingClientRect(),x=Math.floor((ev.clientX-r.left)*canvas.width/r.width),y=Math.floor((ev.clientY-r.top)*canvas.height/r.height);const i=pick[y*canvas.width+x];if(i>=0&&S.visible.includes(i))select(i,false);});canvas.addEventListener('wheel',ev=>{ev.preventDefault();S.camera.scale*=Math.exp(-ev.deltaY*.0012);render()},{passive:false});canvas.oncontextmenu=e=>e.preventDefault();new ResizeObserver(()=>render()).observe($('stage'));

// Presentation layer. Original records, source pages and geometry packages remain immutable.
const PUB=window.ALBUM_PUBLIC,PSET=new Set(PUB.publicIndices),sections=new Map(PUB.sections.map(s=>[s.id,s]));
let UI={section:'building',groupOpen:{},groupPage:{},listScroll:{},axes:true,labels:false,props:false,navOpen:false,desktopNavOpen:true,more:false,clipOpen:false,filterSection:'',selectedGroup:null};
// Must equal the CSS narrow media predicate; verified by the saved-CSS regression.
const NAV_MEDIA='(max-width:800px)';
const navMedia=window.matchMedia?window.matchMedia(NAV_MEDIA):null;
const narrow=()=>navMedia?navMedia.matches:window.innerWidth<=Number(NAV_MEDIA.match(/[0-9.]+/)[0]);
const pageMeta=p=>PUB.pages[typeof p==='string'?p:p?.key];
const pageName=p=>p?.key?.startsWith('tree::')?p.name:(pageMeta(p)?.displayLabel||'Вид модели');
const nameOf=i=>{const n=H?.nodes[H?.byIndex[String(i)]];return n?.kind==='body'?(H.nodes[n.parent].label+' · '+n.label):n?.label||PUB.recordLabels[String(i)]||'Элемент';};
const safeText=s=>String(s||'').replace(/\bR(?:0[1-9]|1[01])(?:[IL]|\s*(?:local|structure))?\b/gi,'').replace(/\bD0[12]\b|\brev\d*\b/gi,'').replace(/\s+/g,' ').replace(/\s*·\s*·\s*/g,' · ').replace(/^[ ·_-]+|[ ·_-]+$/g,'');
const shortState=e=>['aux','local','template'].includes(e.bucket)?'Тип без размещения':e.bucket==='proposal'?'Предложение · не установлено':e.partial?'Частично':'';
function pubIndices(a){return a.filter(i=>PSET.has(i));}
function publicPages(){return [...Object.values(PUB.pages)].filter(p=>p.public&&p.section===UI.section);}
function activeGroup(){const m=pageMeta(S.page);return m?sections.get(UI.section)?.groups.find(g=>g.label===m.group):null;}
function closePanels(){UI.more=false;UI.clipOpen=false;$('morePanel').hidden=true;$('clipPanel').hidden=true;$('moreToggle').setAttribute('aria-expanded','false');$('clipToggle').setAttribute('aria-expanded','false');}
// UI is the sole state: desktopNavOpen is the desktop preference;
// navOpen is the narrow-screen drawer, props is the properties panel.
// Body classes are derived output, never inputs. Narrow drawers are exclusive.
function navVisible(){return narrow()?!!UI.navOpen:!!UI.desktopNavOpen;}
function syncPanelState(){
 const small=narrow();
 if(small&&UI.props)UI.navOpen=false;
 const open=navVisible();
 document.body.classList.toggle('nav-open',small&&open);
 document.body.classList.toggle('nav-collapsed',!small&&!open);
 $('propertyPanel').hidden=!UI.props;
 $('navigation').setAttribute('aria-hidden',String(!open));
 $('navigation').inert=!open;
 $('navToggle').setAttribute('aria-expanded',String(open));
}
function focusAfterPanelChange(){
 const a=document.activeElement;
 if((!navVisible()&&$('navigation').contains?.(a))||(!narrow()&&a===$('closeNav')))
  $('navToggle').focus({preventScroll:true});
 else if(!UI.props&&$('propertyPanel').contains?.(a))
  $('canvas').focus({preventScroll:true});
}
function setNav(open){
 if(narrow()){UI.navOpen=!!open;if(open){UI.props=false;closePanels();}}
 else UI.desktopNavOpen=!!open;
 syncPanelState();focusAfterPanelChange();render();
}
function closeProps(focus=true){UI.props=false;syncPanelState();if(focus)$('canvas').focus({preventScroll:true});}
function showProps(){
 const fromNav=narrow()&&$('navigation').contains?.(document.activeElement);
 UI.props=true;closePanels();if(narrow())UI.navOpen=false;
 syncPanelState();if(fromNav)$('closeProps').focus({preventScroll:true});
}
function chapterOptions(){
 // DEMO_A: filters describe the opened scope, not previously downloaded views.
 const inds=pubIndices(S.scene);
 for(const [field,label]of [['level','Все уровни'],['zone','Все зоны'],['axis','Все оси']]){
  const values=K.unique(inds.map(i=>rows[i][field]).filter(Boolean)).sort((a,b)=>a.localeCompare(b,'ru',{numeric:true}));
  $(field).innerHTML='<option value="">'+label+'</option>'+values.map(v=>'<option value="'+esc(v)+'">'+esc(safeText(v))+'</option>').join('');
  $(field).hidden=values.length===0;$(field).value=S.filters[field]||'';
 }
 syncFilterStatus();
}
async function openSavedPage(mod,id,options={}){
 const navToken=beginNavigation(options),k=mod+'::'+id,m=PUB.pages[k];
 if(!m||!m.public){toast(m?'Страница вне публичного альбома. Текущий вид не изменён.':'Страница не найдена. Выберите вид в меню.');log('route_refused',{key:k,exists:!!m});return false;}
 try{
  await prepareIndex();if(!navigationCurrent(navToken))return false;
  const ps=await pages(mod);if(!navigationCurrent(navToken))return false;
  const p=ps.find(p=>p.id===id);if(!p)throw new Error('Не удалось открыть выбранный вид.');
  const token=++generation;
  UI.listScroll[UI.section]=$('pageList').scrollTop;UI.section=m.section;UI.groupOpen[UI.section+'|'+m.group]=true;
  const gr=sections.get(UI.section).groups.find(g=>g.label===m.group);UI.groupPage[UI.section+'|'+m.group]=Math.floor(gr.pages.indexOf(k)/24);
  closePanels();closeProps(false);$('album').hidden=false;$('drawingPanel').hidden=true;$('sceneLoading').hidden=false;
  S.module=mod;S.page=p;S.opened={kind:'view',pageKey:k};S.node=null;S.treeMode=false;S.context={kind:'view',pageKey:k};S.full=!!options.full;S.selection=null;S.cardIds=[];S.elementPage=0;S.relationsPage=0;
  // UI.treeSelected is only the remembered tree position, not this view's parent.
  resetFilters();
  const isMaster=mod==='master'&&['overview','plan','structure'].includes(id);
  S.scene=isMaster?H.activeIndices.slice():pubIndices(p.indices.slice());
  if(mod==='master'&&id==='structure')S.scene=S.scene.filter(i=>rows[i].category!=='facade');
  if(options.extra!=null&&PSET.has(options.extra)&&!S.scene.includes(options.extra))S.scene.push(options.extra);
  S.visible=S.scene.slice();chapterOptions();Object.assign(S.camera,K.cameraEye(p.eye));fit(S.scene);if(p.clip&&p.range){S.clip=structuredClone(p.range);syncControls();}
  if(!await install(S.scene,token,navToken)||!navigationCurrent(navToken))return false;
  updatePageBar();drawPages();setTab(options.keepTab||'pages');pageCard();
  if(!options.noHash)history.replaceState(null,'','#page/'+encodeURIComponent(mod)+'/'+encodeURIComponent(id));
  if(options.select!=null)select(options.select,true,{navToken});if(narrow())setNav(false);
  log('page_ready',{key:k,generation:token,request:navToken});return true;
 }catch(e){if(navigationCurrent(navToken))error(e);return false;}
}
function drawPages(){const list=$('pageList'),s=sections.get(UI.section);if(!s)return;const sc=list.scrollTop;list.replaceChildren();for(const group of s.groups){const key=UI.section+'|'+group.label,el=document.createElement('details');el.className='group';el.dataset.group=group.label;el.open=!!UI.groupOpen[key];const sum=document.createElement('summary');sum.textContent=group.label;el.append(sum);const area=document.createElement('div');area.className='group-pages';el.append(area);function paint(){area.replaceChildren();const pg=K.slicePage(group.pages,UI.groupPage[key]||0,24);UI.groupPage[key]=pg.page;for(const k of pg.ids){const p=PUB.pages[k],b=document.createElement('button');b.className='pageitem'+(S.page?.key===k?' selected':'');b.dataset.page=k;b.setAttribute('aria-current',S.page?.key===k?'page':'false');b.textContent=p.displayLabel;b.onclick=()=>openPage(p.module,p.id);area.append(b);}if(pg.pages>1){const nav=document.createElement('div');nav.className='pager';area.append(nav);pager(nav,group.pages,pg.page,24,(v,f)=>{UI.groupPage[key]=v;paint();area.querySelector('.pager').querySelectorAll('button')[f==='next'?1:0].focus({preventScroll:true});el.scrollIntoView({block:'nearest'});});}}
paint();el.ontoggle=()=>{UI.groupOpen[key]=el.open;};list.append(el);}list.scrollTop=UI.listScroll[UI.section]??sc;}
function drawLayers(){const list=$('layerList');list.replaceChildren();const groups=new Map();for(const i of pubIndices(S.scene)){const e=rows[i],c=e.category;if(!groups.has(c))groups.set(c,[]);groups.get(c).push(i);}for(const [cat,ids]of groups){const lab=document.createElement('label');lab.className='layer-row';const input=document.createElement('input');input.type='checkbox';input.checked=ids.some(i=>!S.hidden.includes(i));input.dataset.layer=cat;input.onchange=()=>{if(input.checked)S.hidden=S.hidden.filter(i=>!ids.includes(i));else S.hidden=K.unique(S.hidden.concat(ids));reconcileVisibility('layer');};const text=document.createElement('span');text.textContent=PUB.categoryLabels[cat]||'Конструкции';const count=document.createElement('small');count.textContent=ids.length;lab.append(input,text,count);list.append(lab);}}
function drawElements(){if(!rows.length)return;const ids=pubIndices(K.filtered(S.scene,rows,S.filters)),s=K.slicePage(ids,S.elementPage,60);S.elementPage=s.page;$('elementPath').textContent=pageName(S.page);const list=$('elementList');list.replaceChildren();for(const i of s.ids){const e=rows[i],b=document.createElement('button');b.className='elementitem'+(e.key===S.selection?' selected':'');b.dataset.key=e.key;b.innerHTML='<b>'+esc(nameOf(i))+'</b><small>'+esc(safeText(e.level))+(shortState(e)?' · '+esc(shortState(e)):'')+(S.hidden.includes(i)?' · скрыт':'')+'</small>';b.onclick=()=>select(i,true);list.append(b);}pager($('elementPagination'),ids,S.elementPage,60,(v,f)=>{S.elementPage=v;drawElements();$('elementPagination').querySelectorAll('button')[f==='next'?1:0].focus({preventScroll:true});$('elementDetails').scrollIntoView({block:'start'});});}
// opened is the loaded node/view, selection is transient. context is derived output.
function openedContext(){
 const key=S.page?.key||'';
 if(!S.opened||S.opened.pageKey!==key){
  S.opened=key.startsWith('tree::')?{kind:'node',nodeId:key.slice(6),pageKey:key}:{kind:'view',pageKey:key};
 }
 return S.opened.kind==='node'?{kind:'node',nodeId:S.opened.nodeId}:{kind:'view',pageKey:S.opened.pageKey};
}
function effectiveContext(){return S.selection!=null?{kind:'element',key:S.selection}:openedContext();}
function invalidateDrawingContext(){
 visibilityRevision++;navigationSerial++;selectTicket++;drawingSession++;drawingTicket++;
 if(!$('drawingPanel').hidden){$('drawingPanel').hidden=true;beforeDrawing=null;}
}
function pageCard(){
 S.selection=null;S.context=openedContext();S.node=S.context.kind==='node'?S.context.nodeId:null;
 S.cardIds=pubIndices(visibleIds());$('properties').replaceChildren();closeProps(false);$('statusSelection').textContent='';
}
function reconcileVisibility(reason,{invalidate=true,paint=true}={}){
 if(invalidate)invalidateDrawingContext();
 S.visible=visibleIds();const i=keyMap.get(S.selection),dropped=S.selection!=null&&!S.visible.includes(i);
 if(dropped)pageCard();else{S.context=effectiveContext();if(S.selection==null)S.cardIds=pubIndices(S.visible);}
 syncFilterStatus();
 if(paint){updatePageBar();drawTree();drawElements();render();}
 log('context_reconciled',{reason,dropped,opened:openedContext(),context:S.context,visible:S.visible.length});
 // A filter is a later user action than queued page preparation. If mesh
 // installation has already begun, finish this current scope under its new token.
 if(invalidate&&!workerReady&&S.page&&S.scene.length){
  const token=navigationSerial,gen=++generation,ids=S.scene.slice();
  install(ids,gen,token).then(ok=>{if(ok&&navigationCurrent(token))reconcileVisibility('visibility-install',{invalidate:false});}).catch(e=>{if(navigationCurrent(token))error(e);});
 }
 return dropped;
}
function relationList(container,ids,title){ids=pubIndices(ids);if(!ids.length)return;const details=document.createElement('details'),heading=document.createElement('summary');heading.textContent=title+' · '+ids.length;details.append(heading);const area=document.createElement('div'),nav=document.createElement('div');nav.className='pager';details.append(area,nav);container.append(details);let page=0;function paint(){area.replaceChildren();const s=K.slicePage(ids,page,50);for(const i of s.ids){const b=document.createElement('button');b.className='relationitem';b.dataset.key=rows[i].key;b.textContent=nameOf(i);b.onclick=()=>openRecord(rows[i].key);area.append(b);}pager(nav,ids,page,50,(v,f)=>{page=v;paint();nav.querySelectorAll('button')[f==='next'?1:0].focus({preventScroll:true});});}paint();}
function elementCard(i){const e=fullRecords.get(i)||rows[i],p=e.props||{},label=nameOf(i);let html='<h2>'+esc(label)+'</h2>';if(shortState(e))html+='<span class="status '+(e.partial?'partial':'')+'">'+esc(shortState(e))+'</span>';html+=field('Марка',safeText(p.mark||e.group))+field('Материал',p.material||p.bar_class||p.source_profile||'Не указан')+field('Расположение',shortState(e)==='Тип без размещения'?'Тип без размещения':safeText(e.level));const len=p.length_m??p.source_length_mm; if(len!=null)html+=field('Длина',p.length_m!=null?p.length_m+' м':p.source_length_mm+' мм');html+=field('Габариты, м',e.bounds[0].map((v,a)=>(e.bounds[1][a]-v).toLocaleString('ru-RU',{maximumFractionDigits:3})).join(' × '));if(p.quantity!=null||p.model_quantity!=null||p.bar_count!=null)html+=field('Количество',String(p.quantity??p.model_quantity??p.bar_count)+' '+(p.unit||''));html+='<div class="card-actions"><button id="propFocus">Приблизить</button><button id="propIsolate">Изолировать</button><button id="propHide">Скрыть</button></div><button id="propDrawing" class="source-link">Чертёж</button>';if(e.parent)html+='<button id="parentButton" class="source-link">К узлу</button>';html+='<div id="relations"></div><details id="technicalDetails"><summary>Технические сведения</summary>'+field('ID',e.key)+field('Исходное название',e.name)+field('Основание расположения',p.level_basis||rows[i].level_id)+field('Источник',p.source||'См. кнопку «Чертёж»')+'<pre>'+esc(JSON.stringify(p,null,2))+'</pre></details>';$('properties').innerHTML=html;showProps();$('propFocus').onclick=()=>{fit([i]);render()};$('propIsolate').onclick=()=>isolate([i]);$('propHide').onclick=()=>hide([i]);$('propDrawing').onclick=showDrawing;if($('parentButton'))$('parentButton').onclick=()=>openRecord(e.parent_key||(e.ns==='world'?e.parent:e.ns+'::'+e.parent));relationList($('relations'),children.get(e.key)||[],'В составе узла');$('statusSelection').textContent=label;}
function targets(){return pubIndices(S.selection!=null?[keyMap.get(S.selection)]:(S.cardIds.length?S.cardIds:S.visible)).filter(i=>S.visible.includes(i));}
async function runSearch(){const q=$('search').value;await prepareIndex();if(q!==$('search').value)return;searchMatches=K.searchRows(rows,q).filter(i=>PSET.has(i));searchPage=0;drawSearch();}
function friendlySource(s){return safeText(s?.title||'Чертёж').replace(/— кровельные МУ и Б1/,'— монолитные участки и балки');}
function sourceMode(s){return /^Унаследовано/.test(s)?'По узлу':s.startsWith('Источник текущего')?'По текущему виду':s;}
async function openSource(key,mode='Источник элемента',session=drawingSession){const ticket=++drawingTicket,{sources:ss}=await sources();if(session!==drawingSession||ticket!==drawingTicket)return;const s=ss[key];if(!s)return;const title=friendlySource(s);$('drawingTitle').textContent=title;$('drawingInfo').textContent=sourceMode(mode)+' · Лист '+(s.printed_sheet??'не указан')+(s.pdf_page?' · Страница PDF '+s.pdf_page:' · Точная страница PDF не установлена');$('drawingResource').innerHTML='<p class="note">Открываем чертёж…</p>';const pk=await ensurePack(s.file);if(ticket!==drawingTicket||session!==drawingSession)return;const body=$('drawingResource');body.replaceChildren();if(pk.ok){const img=document.createElement('img');img.alt=title;img.src=s.file;img.onerror=()=>{if(ticket===drawingTicket&&session===drawingSession){const p=document.createElement('p');p.className='note warning';p.textContent='Файл чертежа не найден. Повторно распакуйте полный альбом; проверьте папку sources.';body.prepend(p);}};body.append(img);}else{const p=document.createElement('p');p.className='note warning';p.textContent=pk.message;body.append(p);}if(s.pdf&&s.pdf_page){const b=document.createElement('button');b.className='source-link';b.textContent='Полный лист · страница '+s.pdf_page;b.onclick=async()=>{const pk2=await ensurePack(s.pdf);if(ticket!==drawingTicket||session!==drawingSession)return;if(!pk2.ok)return toast(pk2.message);const a=document.createElement('a');a.href=s.pdf+'#page='+s.pdf_page;a.target='_blank';a.rel='noopener';a.textContent='Открыть лист в новой вкладке';const iframe=document.createElement('iframe');iframe.title=title;iframe.src=a.href;body.replaceChildren(a,iframe);};body.prepend(b);}else{const p=document.createElement('p');p.className='note';p.textContent='Показано собственное изображение. Номер страницы полного PDF не определён.';body.append(p);}}
let drawingFocus=null;
async function backDrawing(){drawingTicket++;drawingSession++;$('drawingPanel').hidden=true;const state=beforeDrawing;const ok=await restore(state);if(!ok)return false;if(drawingFocus?.isConnected&&!drawingFocus.hidden&&drawingFocus.getClientRects().length)drawingFocus.focus({preventScroll:true});else $('drawing').focus();return true;}
function showDocs(){dialog('Документы',PUB.publicDocuments.map((d,i)=>'<button class="source-link" data-doc="'+i+'">'+esc(d.name)+'<small>'+esc(d.kind)+'</small></button>').join(''));for(const b of $('dialogBody').querySelectorAll('[data-doc]'))b.onclick=async()=>{const d=PUB.publicDocuments[+b.dataset.doc],pk=await ensurePack(d.file);if(!pk.ok)return toast(pk.message);window.open(d.file,'_blank','noopener');};}
function drawOverlay(){const o=$('overlay');if(!o)return;const c=o.getContext('2d');o.width=canvas.width;o.height=canvas.height;const w=o.width,h=o.height,C=S.camera,cy=Math.cos(C.yaw),sy=Math.sin(C.yaw),cp=Math.cos(C.pitch),sp=Math.sin(C.pitch);function xy(p){const x=p[0]-C.target[0],y=p[1]-C.target[1],z=p[2]-C.target[2];return [w/2+C.pan[0]+(-sy*x+cy*y)*C.scale,h/2+C.pan[1]-(-cy*sp*x-sy*sp*y+cp*z)*C.scale];}c.clearRect(0,0,w,h);if(UI.axes){const z=S.module==='roof'?10.71:S.module==='floors'?((pageMeta(S.page)?.group==='Над 2 этажом')?7.11:3.51):0;const xs=[0,6,9,12,18,24,30,33,36,42,48],xn=['1','2','2/3','3','4','5','6','6/7','7','8','9'],yn=['А','Б','В','Г','Д','Е','Ж','И','К'];c.strokeStyle='#839da760';c.lineWidth=1;function line(a,b,label){const p=xy(a),q=xy(b);c.beginPath();c.moveTo(...p);c.lineTo(...q);c.stroke();c.font='12px Arial';c.textAlign='center';c.fillStyle='#ffffffdd';c.fillRect(p[0]-12,p[1]-11,24,16);c.fillStyle='#5b7c87';c.fillText(label,p[0],p[1]+1);}xs.forEach((x,i)=>line([x,-2,z],[x,50,z],xn[i]));yn.forEach((n,i)=>line([-2,i*6,z],[50,i*6,z],n));}if(UI.labels){const done=new Set();c.font='12px Arial';for(const i of S.visible){const e=rows[i];if(!e.group||e.group.includes('_')||['facade','body'].includes(e.group)||done.has(e.group))continue;done.add(e.group);const p=e.bounds[0].map((v,a)=>(v+e.bounds[1][a])/2);p[2]+=offsets()[i]||0;const v=xy(p);if(v[0]<0||v[0]>w||v[1]<0||v[1]>h)continue;const text=safeText(e.group),tw=c.measureText(text).width;c.fillStyle='#ffffffdd';c.fillRect(v[0]-4,v[1]-13,tw+8,18);c.fillStyle='#173541';c.fillText(text,...v);if(done.size>50)break;}}}

// rev04: composition hierarchy. Original geometry and saved pages remain immutable.
let H=null,hierarchyPromise=null;
async function prepareHierarchy(){if(H)return H;if(!hierarchyPromise)hierarchyPromise=loadData('hierarchy','data/hierarchy.js').then(h=>{H=h;UI.treeSelected='building';UI.treeExpanded=UI.treeExpanded||{building:true,construction:true};UI.treePage=UI.treePage||0;return h;});return hierarchyPromise;}
function currentTreeId(){const c=effectiveContext();return c.kind==='element'?H?.byKey[c.key]:c.kind==='node'?c.nodeId:null;}
function hnode(){return H?.nodes[currentTreeId()];}
function treeIndices(id,includeTypes=false){const n=H?.nodes[id];if(!n)return[];if(id==='building'||id==='construction')return H.activeIndices.slice();let a=H.order.slice(...n.span);if(n.physical_count&&!includeTypes)a=a.filter(i=>rows[i].physical&&rows[i].bucket==='active');return a;}
function nodePath(id){const a=[];let n=H?.nodes[id],seen=new Set();while(n&&!seen.has(n.id)){seen.add(n.id);a.push(n);n=H.nodes[n.parent];}return a.reverse();}
function flatTree(){const a=[];if(!H)return a;function walk(id,depth){const n=H.nodes[id];a.push({id,depth});if(UI.treeExpanded?.[id])for(const c of n.children)walk(c,depth+1);}walk('building',0);return a;}
function treeFocus(id){const all=flatTree(),at=all.findIndex(x=>x.id===id);if(at<0)return;UI.treePage=Math.floor(at/80);drawTree();const b=$('objectTree').querySelector('[data-node="'+id.replace(/"/g,'\\"')+'"]');b?.focus({preventScroll:true});b?.scrollIntoView({block:'nearest'});}
function revealTree(id,scroll=true){if(!H?.nodes[id])return;UI.treeSelected=id;for(const n of nodePath(id).slice(0,-1))UI.treeExpanded[n.id]=true;const a=flatTree(),at=a.findIndex(x=>x.id===id);UI.treePage=Math.max(0,Math.floor(at/80));drawTree();if(scroll){const b=$('objectTree').querySelector('[data-node="'+id.replace(/"/g,'\\"')+'"]');b?.scrollIntoView({block:'nearest'});}}
function toggleTree(id){const n=H.nodes[id];if(!n.children.length)return;UI.treeExpanded[id]=!UI.treeExpanded[id];drawTree();const b=$('objectTree').querySelector('[data-expand="'+id.replace(/"/g,'\\"')+'"]');b?.focus({preventScroll:true});}
function drawTree(){if(!H)return;const pane=$('treePanel'),sc=pane.scrollTop,list=$('objectTree'),a=flatTree(),pg=K.slicePage(a,UI.treePage||0,80);UI.treePage=pg.page;list.replaceChildren();for(const {id,depth}of pg.ids){const n=H.nodes[id],row=document.createElement('div');row.className='object-tree-row'+(currentTreeId()===id?' selected':'');row.style.setProperty('--tree-depth',Math.min(depth,5));row.dataset.treeRow=id;row.setAttribute('role','treeitem');row.setAttribute('aria-level',String(depth+1));row.setAttribute('aria-selected',String(currentTreeId()===id));if(n.children.length)row.setAttribute('aria-expanded',String(!!UI.treeExpanded[id]));const arrow=document.createElement('button');arrow.className='tree-arrow';arrow.dataset.expand=id;arrow.textContent=n.children.length?(UI.treeExpanded[id]?'▾':'▸'):'·';arrow.disabled=!n.children.length;arrow.setAttribute('aria-label',(UI.treeExpanded[id]?'Свернуть ':'Раскрыть ')+n.label);arrow.onclick=()=>toggleTree(id);const b=document.createElement('button');b.className='tree-label';b.dataset.node=id;b.textContent=n.label;b.title=nodePath(id).map(x=>x.label).join(' → ');b.onclick=()=>openNode(id,{focus:true});b.onkeydown=e=>{if(e.key==='ArrowRight'){e.preventDefault();UI.treeExpanded[id]=true;drawTree();treeFocus(id);}else if(e.key==='ArrowLeft'){e.preventDefault();if(UI.treeExpanded[id]){UI.treeExpanded[id]=false;drawTree();treeFocus(id);}else if(n.parent)treeFocus(n.parent);}else if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const all=flatTree(),at=all.findIndex(x=>x.id===id),j=e.key==='Home'?0:e.key==='End'?all.length-1:Math.max(0,Math.min(all.length-1,at+(e.key==='ArrowDown'?1:-1)));treeFocus(all[j].id);}};row.append(arrow,b);list.append(row);}pager($('treePagination'),a,pg.page,80,(v,f)=>{UI.treePage=v;drawTree();$('treePagination').querySelectorAll('button')[f==='next'?1:0]?.focus({preventScroll:true});pane.scrollTop=0;});pane.scrollTop=sc;}

function syncFilterStatus(){
 $('filterStatus').textContent=S.page?'Видно '+fmt(S.visible.length)+' из '+fmt(S.scene.length):'';
 $('emptyScene').hidden=!S.page||S.visible.length!==0;
}
function resetViewFilters(){
 resetFilters();S.elementPage=0;
 reconcileVisibility('reset-view');drawLayers();fit(S.visible);render();
}
$('resetViewFilters').onclick=resetViewFilters;$('emptySceneReset').onclick=resetViewFilters;
function syncUpButton(){
 const context=effectiveContext(),id=context.kind==='element'?H?.byKey[context.key]:context.kind==='node'?context.nodeId:null;
 const parent=H?.nodes[id]?.parent;
 $('upOneLevel').hidden=!parent;
 $('upOneLevel').onclick=()=>parent?openNode(parent):home();
}

function hierarchyBar(){const n=hnode();if(!n)return;syncUpButton();const ownSection=nodePath(n.id).find(x=>x.kind==='section')?.id?.split(':')[1];$('sectionSelect').value=['facade','master'].includes(ownSection)?ownSection:UI.section;$('topPath').textContent=n.id==='building'?'':n.label;$('sectionTitle').textContent='Состав здания';$('sectionCounts').textContent='';$('pageTitle').textContent=n.label;$('pageHint').textContent=n.physical_count===0&&n.record_count?'Тип без размещения':'';const path=nodePath(n.id);$('breadcrumb').replaceChildren();for(const p of path){const b=document.createElement('button');b.className='breadcrumb-link';b.textContent=p.label;b.onclick=()=>openNode(p.id);$('breadcrumb').append(b);}const sib=n.parent?H.nodes[n.parent].children:[],at=sib.indexOf(n.id);$('pageNumber').textContent='';$('prev').disabled=at<=0;$('next').disabled=at<0||at===sib.length-1;$('explodeLabel').hidden=!S.page?.explode;$('statusSelection').textContent='';}
function updatePageBar(){syncUpButton();syncFilterStatus();if(currentTreeId()){hierarchyBar();return;}const m=pageMeta(S.page),s=sections.get(m?.section||UI.section);if(!s)return;UI.section=s.id;$('sectionSelect').value=s.id;$('sectionTitle').textContent='Готовые виды';$('sectionCounts').textContent='';const g=activeGroup(),at=g?.pages.indexOf(S.page.key)??0;$('topPath').textContent=s.label;$('breadcrumb').textContent=[s.label,m?.group].filter(Boolean).join(' / ');$('pageTitle').textContent=pageName(S.page);$('pageNumber').textContent=(at+1)+' из '+(g?.pages.length||1);$('prev').disabled=at<=0;$('next').disabled=!g||at>=g.pages.length-1;$('pageHint').textContent=m?.isType?'Тип без размещения':'';$('explodeLabel').hidden=!S.page?.explode;}
function setTab(tab){S.tab=tab;$('treePanel').hidden=tab!=='tree';$('pageList').hidden=tab!=='pages';$('elementPanel').hidden=tab!=='elements';$('searchPanel').hidden=tab!=='search';for(const[id,t]of [['treeTab','tree'],['pagesTab','pages'],['elementsTab','elements'],['searchTab','search']]){const b=$(id),on=tab===t;b.setAttribute('aria-selected',String(on));b.classList.toggle('on',on);b.tabIndex=on?0:-1;}if(tab==='tree')drawTree();if(tab==='elements'){drawLayers();drawElements();}if(tab==='pages')drawPages();if(tab==='search')drawSearch();}
function nodeCard(id){const n=H.nodes[id],ids=treeIndices(id).filter(i=>S.visible.includes(i));S.selection=null;S.context={kind:'node',nodeId:id};S.cardIds=ids;let html='<h2>'+esc(n.label)+'</h2>'+(n.physical_count?'': '<span class="status">Тип без размещения</span>')+'<div class="field"><label>Расположение в составе</label>'+esc(nodePath(id).map(x=>x.label).join(' → '))+'</div><div class="card-actions"><button id="nodeFit">Приблизить</button><button id="nodeIsolate">Изолировать</button></div><button id="nodeDrawing" class="source-link">Чертёж</button><div id="nodeLinks"></div><div id="relations"></div><details><summary>Сведения о составе</summary><p>Физических тел: '+n.physical_count+'</p><pre>'+esc(JSON.stringify(n.evidence,null,2))+'</pre></details>';$('properties').innerHTML=html;showProps();$('nodeFit').onclick=()=>{fit(ids);render();};$('nodeIsolate').onclick=()=>isolate(ids);$('nodeDrawing').onclick=showDrawing;const p=H.nodes[n.parent];if(p){const b=document.createElement('button');b.className='source-link';b.textContent='К родителю · '+p.label;b.onclick=()=>openNode(p.id);$('nodeLinks').append(b);}if(n.model_key)relationList($('relations'),children.get(n.model_key)||[],'В составе узла');}
async function openNode(id,opts={}){
 const navToken=beginNavigation(opts);
 await prepareIndex();if(!navigationCurrent(navToken))return false;
 await prepareHierarchy();if(!navigationCurrent(navToken))return false;
 const n=H.nodes[id];if(!n){toast('Узел не найден. Текущий выбор сохранён.');return false;}
 const ids=treeIndices(id);if(!ids.length){toast('У узла нет доступной геометрии.');return false;}
 const token=++generation,visibilityAtStart=visibilityRevision;closePanels();closeProps(false);$('drawingPanel').hidden=true;$('sceneLoading').hidden=false;
 UI.treeSelected=id;const ownSection=nodePath(id).find(x=>x.kind==='section')?.id?.split(':')[1]||'master';
 UI.section=sections.has(opts.section)?opts.section:({master:'building',facade:'building',placed_frames:'frames'}[ownSection]||ownSection);if(!sections.has(UI.section))UI.section='building';$('sectionSelect').value=UI.section;
 S.module=['building','construction'].includes(id)?'master':ownSection;S.opened={kind:'node',nodeId:id,pageKey:'tree::'+id};S.node=id;S.treeMode=true;S.context={kind:'node',nodeId:id};
 S.page={id,key:'tree::'+id,name:n.label,module:S.module,source:(n.sources||[]).map(s=>s.key),indices:ids,eye:opts.eye||[-1,-1,1],explode:null};
 S.full=true;S.scene=ids;S.visible=ids.slice();S.selection=null;S.cardIds=[];S.elementPage=0;S.relationsPage=0;
 resetFilters();chapterOptions();Object.assign(S.camera,K.cameraEye(S.page.eye));fit(ids);revealTree(id,opts.scroll!==false);hierarchyBar();setTab('tree');
 if(!opts.noHash)history.replaceState(null,'','#node/'+encodeURIComponent(id));
 if(!await install(ids,token,navToken)||!navigationCurrent(navToken))return false;
 S.visible=visibleIds();if(id==='building'||visibilityAtStart!==visibilityRevision)pageCard();else if(n.self.length===1&&!n.children.length)select(n.self[0],false,{navToken});else nodeCard(id);updatePageBar();drawTree();render();
 if(narrow()&&!opts.keepMenu)setNav(false);log('hierarchy_ready',{node:id,ids:ids.length,generation:token,request:navToken});return true;
}
async function openPage(mod,id,opts={}){
 const navToken=beginNavigation(opts);
 await prepareIndex();if(!navigationCurrent(navToken))return false;
 await prepareHierarchy();if(!navigationCurrent(navToken))return false;
 if(!PUB.pages[mod+'::'+id]?.public){toast('Страница не найдена или вне текущего альбома. Выбор сохранён.');return false;}
 // Prepared views retain their own identity/source/camera. A full default
 // building and a no-facade view are different, explicitly filtered sets.
 return openSavedPage(mod,id,{...opts,navToken});
}
function home(){return openNode('building');}
function select(i,focus=true,opts={}){
 const navToken=beginNavigation(opts);if(!navigationCurrent(navToken)||!rows[i]||!PSET.has(i))return false;
 if(!S.scene.includes(i))return openRecord(rows[i].key,{navToken});
 S.selection=rows[i].key;S.context={kind:'element',key:S.selection};S.cardIds=[i];S.hidden=S.hidden.filter(v=>v!==i);
 if(!K.filtered([i],rows,S.filters).length){S.filters={level:'',state:'',zone:'',axis:''};syncControls();}
 S.visible=visibleIds();const nid=H?.byIndex[String(i)];
 if(nid){revealTree(nid,true);setTab('tree');hierarchyBar();}
 S.elementPage=Math.floor(K.filtered(S.scene,rows,S.filters).indexOf(i)/60);elementCard(i);
 const pb=$('parentButton');if(pb&&nid)pb.onclick=()=>openNode(H.nodes[nid].parent);
 if(focus)fit([i]);render();return true;
}
async function openRecord(key,opts={}){
 const navToken=beginNavigation(opts);
 await prepareIndex();if(!navigationCurrent(navToken))return false;
 await prepareHierarchy();if(!navigationCurrent(navToken))return false;
 const nid=H.byKey[key]||Object.keys(H.nodes).find(k=>H.nodes[k].model_key===key);
 if(!nid){toast('Элемент вне текущего альбома или не найден. Выбор сохранён.');return false;}
 const i=keyMap.get(key);
 if(i!=null&&S.scene.includes(i)&&workerReady){return select(i,true,{navToken});}
 const ok=await openNode(nid,{focus:true,navToken});if(!navigationCurrent(navToken))return false;
 if(ok&&i!=null&&S.scene.includes(i))select(i,true,{navToken});return ok;
}
function snapshot(){return{...structuredClone(S),ui:structuredClone(UI),navCollapsed:!UI.desktopNavOpen,pageKey:S.page?.key,listScroll:$('pageList').scrollTop,treeScroll:$('treePanel').scrollTop,elementScroll:$('elementPanel').scrollTop,propertyScroll:$('properties').scrollTop,searchQuery:$('search').value,searchPage,searchScroll:$('searchPanel').scrollTop};}
async function restore(s,opts={}){
 const navToken=beginNavigation(opts);if(!s?.pageKey)return openNode('building',{navToken});
 await prepareIndex();if(!navigationCurrent(navToken))return false;
 await prepareHierarchy();if(!navigationCurrent(navToken))return false;
 const istree=s.pageKey.startsWith('tree::');
 if(!istree&&!PUB.pages[s.pageKey]?.public){toast('Сохранённая страница вне текущего альбома.');return false;}
 if(!istree){await pages(s.pageKey.split('::')[0]);if(!navigationCurrent(navToken))return false;}
 const token=++generation,panels={props:!!s.ui?.props,navOpen:!!s.ui?.navOpen,desktopNavOpen:typeof s.ui?.desktopNavOpen==='boolean'?s.ui.desktopNavOpen:!s.navCollapsed};
 UI={...UI,...structuredClone(s.ui||{}),...panels};S=structuredClone(s);delete S.ui;
 if(!istree)S.page=pageData.get(s.pageKey.split('::')[0]).find(p=>p.key===s.pageKey);
 S.opened=istree?{kind:'node',nodeId:s.pageKey.slice(6),pageKey:s.pageKey}:{kind:'view',pageKey:s.pageKey};S.node=istree?S.opened.nodeId:null;S.treeMode=istree;S.context=effectiveContext();
 S.scene=pubIndices(S.scene);chapterOptions();reconcileVisibility('restore',{invalidate:false,paint:false});syncControls();$('drawingPanel').hidden=true;$('sceneLoading').hidden=false;
 if(!await install(S.scene,token,navToken)||!navigationCurrent(navToken))return false;
 updatePageBar();drawTree();drawPages();$('search').value=s.searchQuery||'';searchPage=s.searchPage||0;searchMatches=K.searchRows(rows,$('search').value).filter(i=>PSET.has(i));setTab(s.tab||'tree');
 if(S.selection&&keyMap.has(S.selection))elementCard(keyMap.get(S.selection));else if(panels.props&&S.context.kind==='node')nodeCard(S.context.nodeId);else{$('properties').replaceChildren();S.cardIds=pubIndices(S.visible);}
 Object.assign(UI,panels);syncPanelState();focusAfterPanelChange();
 $('pageList').scrollTop=s.listScroll||0;$('treePanel').scrollTop=s.treeScroll||0;$('elementPanel').scrollTop=s.elementScroll||0;$('properties').scrollTop=s.propertyScroll||0;$('searchPanel').scrollTop=s.searchScroll||0;
 history.replaceState(null,'',istree?'#node/'+encodeURIComponent(s.pageKey.slice(6)):'#page/'+encodeURIComponent(S.module)+'/'+encodeURIComponent(S.page.id));
 $('axesToggle').setAttribute('aria-pressed',String(UI.axes));$('labelsToggle').setAttribute('aria-pressed',String(UI.labels));closePanels();render();return true;
}
async function showDrawing(){
 reconcileVisibility('drawing',{invalidate:false});const session=++drawingSession,nav=navigationSerial;
 await prepareHierarchy();if(session!==drawingSession||nav!==navigationSerial)return false;
 beforeDrawing=snapshot();drawingFocus=document.activeElement;
 const context=structuredClone(effectiveContext());
 const page=structuredClone(S.page),nid=context.kind==='element'?H.byKey[context.key]:context.kind==='node'?context.nodeId:null;
 const title=context.kind==='view'?[sections.get(UI.section)?.label,pageName(page)].filter(Boolean).join(' → '):nodePath(nid).map(n=>n.label).join(' → ');
 closePanels();$('drawingPanel').hidden=false;$('drawingContext').textContent=title;$('backModel').focus();$('drawingTitle').textContent='';$('drawingInfo').textContent='';$('drawingResource').replaceChildren();$('drawingList').innerHTML='<p class="note">Открываем источники…</p>';
 const {sources:ss,extras}=await sources();if(session!==drawingSession||nav!==navigationSerial)return false;
 let links=[],mode='';
 if(context.kind==='element'){
  const i=keyMap.get(context.key);links=(rows[i]?.sources||[]).filter(s=>s.method!=='navigation_evidence'&&ss[s.key]);
  if(extras?.[context.key])links.push(...extras[context.key].filter(s=>ss[s.key]));if(links.length)mode='Источник элемента';
 }
 if(!links.length&&context.kind!=='view'&&nid){
  for(const n of nodePath(nid).reverse()){
   const ls=(n.sources||[]).filter(s=>s.method!=='navigation_evidence'&&ss[s.key]);
   if(ls.length){links=ls;mode=context.kind==='node'&&n.id===nid?'Источник узла':'По узлу · '+n.label;break;}
  }
 }
 if(context.kind==='view'){
  // A remembered previous tree row is not related to this prepared view.
  links=(Array.isArray(page?.source)?page.source:[page?.source]).filter(k=>ss[k]).map(key=>({key}));mode='Источник выбранного вида';
 }
 if(!S.visible.length){links=[];mode='В текущем виде нет видимых элементов';}
 links=links.filter((s,n,a)=>ss[s.key]&&a.findIndex(x=>x.key===s.key)===n);
 const list=$('drawingList');list.innerHTML='<p class="sourcehint">'+esc(mode)+'</p>';
 for(const l of links){const b=document.createElement('button');b.className='source-link';b.dataset.source=l.key;b.textContent=friendlySource(ss[l.key]);b.onclick=()=>openSource(l.key,mode,session);list.append(b);}
 if(links.length)await openSource(links[0].key,mode,session);else{
  $('drawingTitle').textContent='Чертёж не привязан';$('drawingInfo').textContent=title;
  $('drawingResource').innerHTML='<p class="note">У текущего выбора нет подтверждённого чертежа. Источник прошлого объекта не используется.</p><button id="drawingDocs">Документы</button>';$('drawingDocs').onclick=showDocs;
 }
 return session===drawingSession;
}
function drawSearch(){const q=$('search').value.trim();if(!q){$('searchCount').textContent='Название, марка, размер или ID';$('searchResults').replaceChildren();$('searchPagination').replaceChildren();return;}$('searchCount').textContent='Найдено: '+fmt(searchMatches.length);const list=$('searchResults');list.replaceChildren();const pg=K.slicePage(searchMatches,searchPage,30);for(const i of pg.ids){const n=H?.nodes[H.byIndex[String(i)]],b=document.createElement('button');b.className='resultitem';b.dataset.key=rows[i].key;b.innerHTML='<b>'+esc(nameOf(i))+'</b><small>'+esc(nodePath(n?.id).slice(2,-1).map(n=>n.label).join(' → '))+'</small>';b.onclick=()=>openRecord(rows[i].key);list.append(b);}if(!pg.ids.length){const p=document.createElement('p');p.className='note';p.textContent='Ничего не найдено. Попробуйте марку или размер.';list.append(p);}pager($('searchPagination'),searchMatches,searchPage,30,(v,f)=>{searchPage=v;drawSearch();$('searchPagination').querySelectorAll('button')[f==='next'?1:0]?.focus({preventScroll:true});$('searchPanel').scrollTop=0;});}
async function ensurePack(file){const declared=!!window.ALBUM_SOURCE_FILES?.[file]||PUB.publicDocuments.some(d=>d.file===file);if(!declared)return{ok:false,message:'Путь чертежа не зарегистрирован: '+file};return{ok:true};}
function help(){dialog('Управление моделью','<p>«Всё здание» показывает полную сборку. Вкладка «Состав»: раскрывайте стрелку, чтобы увидеть детали; нажмите название, чтобы посмотреть узел.</p><p>Мышь — вращение, Shift и мышь — перемещение, колесо — масштаб. Поиск раскрывает путь элемента. «Выше» возвращает к родительской сборке.</p><p>Вкладка «Слои» фильтрует текущую сборку. «Сбросить вид» снимает фильтры и разрез, возвращает скрытые слои. «Всё здание» возвращает полный общий вид.</p><p>«Чертёж» — источник выбора. «К модели» восстанавливает вид, панели и раскрытые ветви. Стрелки клавиатуры работают в дереве.</p>');}

for(const m of CAT.chapters)modules.set(m.id,m);for(const b of CAT.blocks)blockMap.set(b.id,b);
$('sectionSelect').innerHTML=PUB.sections.concat([{id:'facade',label:'Фасады'},{id:'master',label:'Общие конструкции'}]).map(s=>'<option value="'+s.id+'">'+esc(s.label)+'</option>').join('');
$('sectionSelect').onchange=()=>{const sec=sections.get($('sectionSelect').value),p=PUB.pages[sec.defaultKey];openPage(p.module,p.id);};
$('home').onclick=home;$('contents').onclick=()=>{dialog('Разделы альбома',PUB.sections.map(s=>'<button class="dialog-section" data-section="'+s.id+'">'+esc(s.label)+'</button>').join(''));for(const b of $('dialogBody').querySelectorAll('[data-section]'))b.onclick=()=>{$('dialog').close();const p=PUB.pages[sections.get(b.dataset.section).defaultKey];openPage(p.module,p.id);};};
$('pagesTab').onclick=()=>setTab('pages');$('elementsTab').onclick=()=>setTab('elements');$('searchTab').onclick=()=>{setTab('search');$('search').focus();};
for(const [id,tab]of [['pagesTab','pages'],['elementsTab','elements'],['searchTab','search']])$(id).onkeydown=e=>{const a=['pagesTab','elementsTab','searchTab'],j=a.indexOf(id);if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const k=(j+(e.key==='ArrowRight'?1:2))%3;setTab(['pages','elements','search'][k]);$(a[k]).focus();}};
$('searchClear').onclick=()=>{$('search').value='';searchMatches=[];drawSearch();$('search').focus();};
$('navToggle').onclick=()=>setNav(!navVisible());
$('closeNav').onclick=()=>{setNav(false);$('navToggle').focus();};$('closeProps').onclick=()=>closeProps();
$('help').onclick=help;$('quickHelp').onclick=help;$('documents').onclick=showDocs;$('documentsMobile').onclick=showDocs;
$('moreToggle').onclick=()=>{const open=$('morePanel').hidden;closePanels();if(open){closeProps(false);$('morePanel').hidden=false;$('moreToggle').setAttribute('aria-expanded','true');UI.more=true;}};
$('clipToggle').onclick=()=>{const open=$('clipPanel').hidden;closePanels();if(open){closeProps(false);$('clipPanel').hidden=false;$('clipToggle').setAttribute('aria-expanded','true');UI.clipOpen=true;}};
$('axesToggle').onclick=()=>{UI.axes=!UI.axes;$('axesToggle').setAttribute('aria-pressed',String(UI.axes));drawOverlay();};$('labelsToggle').onclick=()=>{UI.labels=!UI.labels;$('labelsToggle').setAttribute('aria-pressed',String(UI.labels));drawOverlay();};
$('prev').onclick=()=>{const g=activeGroup(),n=g.pages.indexOf(S.page.key);if(n>0){const p=PUB.pages[g.pages[n-1]];openPage(p.module,p.id);}};$('next').onclick=()=>{const g=activeGroup(),n=g.pages.indexOf(S.page.key);if(n<g.pages.length-1){const p=PUB.pages[g.pages[n+1]];openPage(p.module,p.id);}};
$('drawing').onclick=showDrawing;$('cardDrawing').onclick=showDrawing;$('backModel').onclick=backDrawing;
$('resetCamera').onclick=()=>{Object.assign(S.camera,K.cameraEye(S.page?.eye));fit(S.visible);render();};
$('showPage').onclick=()=>openPage(S.module,S.page.id,{full:S.full});
$('isolate').onclick=()=>isolate(targets()).catch(error);$('hide').onclick=()=>hide(targets());$('restore').onclick=()=>{S.hidden=[];reconcileVisibility('unhide');drawLayers();};
$('saved').onclick=()=>{dialog('Мои виды',stored.length?stored.map((v,i)=>'<button class="source-link" data-saved="'+i+'">'+esc(safeText(v.label))+'</button>').join(''):'<p>Сохранённых видов ещё нет.</p>');for(const b of $('dialogBody').querySelectorAll('[data-saved]'))b.onclick=()=>{$('dialog').close();restore(stored[+b.dataset.saved].state).catch(error);};};
$('saveView').onclick=()=>{const label=prompt('Название вида',pageName(S.page));if(label===null)return;stored.push({label,state:snapshot()});try{localStorage.setItem('B24_ALBUM_R10_UI_VIEWS',JSON.stringify(stored));}catch(_){toast('Вид сохранён в текущем открытии.');}toast('Вид сохранён.');};
window.addEventListener('keydown',ev=>{if(ev.key==='Escape'){if(!$('drawingPanel').hidden){ev.preventDefault();backDrawing();}else if($('dialog').open){$('dialog').close();}else if(!$('morePanel').hidden||!$('clipPanel').hidden){closePanels();$('moreToggle').focus();}else if(UI.props){closeProps();}else if(narrow()&&UI.navOpen){setNav(false);$('navToggle').focus();}}});
$('drawingPanel').addEventListener('keydown',ev=>{if(ev.key!=='Tab')return;const ls=[...$('drawingPanel').querySelectorAll('button,a[href],iframe')].filter(e=>!e.disabled&&e.getClientRects().length);if(!ls.length)return;const first=ls[0],last=ls[ls.length-1];if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}});
window.addEventListener('resize',()=>{syncPanelState();focusAfterPanelChange();render();});
function route(){const n=location.hash.match(/^#node\/(.+)$/);if(n)return openNode(decodeURIComponent(n[1]),{noHash:true});const m=location.hash.match(/^#page\/([^/]+)\/(.+)$/);if(m)return openPage(decodeURIComponent(m[1]),decodeURIComponent(m[2]),{noHash:true});return home();}window.addEventListener('hashchange',route);
window.ALBUM_APP={catalog:CAT,publicNavigation:PUB,core:K,getState:()=>({...snapshot(),navigationSerial,generation,pickGeneration,activeBlocks:activeBlocks.slice(),cacheBlocks:[...blockCache.keys()],residentBytes:[...blockCache.values()].reduce((n,b)=>n+b.binary.byteLength,0),workerBytes:activeBlocks.reduce((n,id)=>n+blockMap.get(id).geometry_bytes,0),lastFrame,loadLog:loadLog.slice()}),openPage,openRecord,home,select,showDrawing,backDrawing,restore,snapshot,prepareIndex,getRows:()=>rows,publicIndices:()=>PUB.publicIndices.slice(),getRelations:key=>({children:children.get(key)||[],replacements:replacements.get(key)||[]}),findVisiblePixel:key=>{const i=keyMap.get(key);if(!pick||pickGeneration!==generation)return null;const r=canvas.getBoundingClientRect();for(let at=0;at<pick.length;at++)if(pick[at]===i){const x=at%canvas.width,y=Math.floor(at/canvas.width);return{x:r.left+(x+.5)*r.width/canvas.width,y:r.top+(y+.5)*r.height/canvas.height};}return null;}};

$('treeTab').onclick=()=>setTab('tree');
for(const[id,tab]of [['treeTab','tree'],['pagesTab','pages'],['elementsTab','elements'],['searchTab','search']])$(id).onkeydown=e=>{const ids=['treeTab','pagesTab','elementsTab','searchTab'],ts=['tree','pages','elements','search'],j=ids.indexOf(id);if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const at=(j+(e.key==='ArrowRight'?1:3))%4;setTab(ts[at]);$(ids[at]).focus();}};
$('contents').textContent='Всё здание';$('contents').onclick=home;
$('prev').onclick=()=>{if(currentTreeId()&&H){const n=hnode(),p=H.nodes[n?.parent],at=p?.children.indexOf(n.id);if(at>0)openNode(p.children[at-1]);}else{const g=activeGroup(),at=g?.pages.indexOf(S.page.key);if(at>0){const p=PUB.pages[g.pages[at-1]];openPage(p.module,p.id);}}};
$('next').onclick=()=>{if(currentTreeId()&&H){const n=hnode(),p=H.nodes[n?.parent],at=p?.children.indexOf(n.id);if(p&&at<p.children.length-1)openNode(p.children[at+1]);}else{const g=activeGroup(),at=g?.pages.indexOf(S.page.key);if(g&&at<g.pages.length-1){const p=PUB.pages[g.pages[at+1]];openPage(p.module,p.id);}}};
$('home').onclick=home;$('showPage').textContent='Всё здание';$('showPage').onclick=home;
$('loadDetails').hidden=true;$('loadDetails').onclick=home;
function openSection(sec){
 const sm={facade:'facade',master:'master',foundations:'foundations',ground:'ground',floors:'floors',stair:'stair',entrances:'entrances',lifts:'lifts',openings:'openings',frames:'placed_frames',equipment:'equipment',chamber:'chamber',roof:'roof'};
 return openNode(sec==='building'?'building':'section:'+(sm[sec]||'master'),{section:sec});
}
$('sectionSelect').onchange=()=>openSection($('sectionSelect').value);
$('inBuilding').textContent='Всё здание';$('inBuilding').onclick=home;
Object.assign(window.ALBUM_APP,{prepareHierarchy,openNode,openSection,treeIndices,flatTree,toggleTree,getHierarchy:()=>H,getPath:key=>nodePath(H?.byKey[key]||key).map(n=>({id:n.id,label:n.label})),treeFocus});

syncPanelState();window.ALBUM_READY=true;log('ui_ready');const bootNavigation=navigationSerial;prepareIndex().then(prepareHierarchy).then(()=>navigationSerial===bootNavigation?route():false).catch(error);

})();
